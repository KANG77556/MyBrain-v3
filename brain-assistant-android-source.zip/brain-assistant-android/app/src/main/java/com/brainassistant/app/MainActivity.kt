package com.brainassistant.app

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

class MainActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var encryptedPrefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        encryptedPrefs = EncryptedSharedPreferences.create(
            "secure_settings",
            masterKeyAlias,
            this,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.surface))
        }

        val header = TextView(this).apply {
            text = "브레인 비서"
            textSize = 24f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
            setPadding(dp(20), dp(24), dp(20), dp(16))
        }
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(32))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addSummaryCard()
        addPriorityCard()
        addQuickActions()
        addNavigationButtons()

        setContentView(root)
    }

    private fun addSummaryCard() {
        addCard("오늘의 브리핑", "일정 0건 · 할 일 0건 · 지연 0건\nAI 키를 연결하면 음성·문서 분석을 사용할 수 있습니다.")
    }

    private fun addPriorityCard() {
        addCard("가장 먼저 할 일", "등록된 우선 업무가 없습니다.\n아래 빠른 입력에서 새 할 일을 만들어 보세요.")
    }

    private fun addQuickActions() {
        val box = verticalBox()
        box.addView(titleText("빠른 입력"))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("음성", "메모", "일정", "할 일").forEach { label ->
            row.addView(Button(this).apply {
                text = label
                setOnClickListener { toast("$label 입력 기능은 다음 구현 단계에서 연결됩니다.") }
            }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        }
        box.addView(row)
        content.addView(box, cardParams())
    }

    private fun addNavigationButtons() {
        val settings = Button(this).apply {
            text = "AI 설정"
            setOnClickListener { showAiSettings() }
        }
        content.addView(settings, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })

        val diagnostic = Button(this).apply {
            text = "앱 상태 검사"
            setOnClickListener {
                val provider = encryptedPrefs.getString("provider", "GPT")
                val hasKey = !encryptedPrefs.getString("api_key", "").isNullOrBlank()
                toast("AI 제공자: $provider / API 키: ${if (hasKey) "등록됨" else "미등록"}")
            }
        }
        content.addView(diagnostic, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })
    }

    private fun showAiSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.surface))
        }

        root.addView(titleText("AI 설정"))

        val providerLabel = TextView(this).apply {
            text = "AI 제공자"
            textSize = 16f
            setPadding(0, dp(20), 0, dp(8))
        }
        root.addView(providerLabel)

        val providerGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val gpt = RadioButton(this).apply { text = "GPT"; id = View.generateViewId() }
        val gemini = RadioButton(this).apply { text = "Gemini"; id = View.generateViewId() }
        providerGroup.addView(gpt)
        providerGroup.addView(gemini)
        val savedProvider = encryptedPrefs.getString("provider", "GPT")
        providerGroup.check(if (savedProvider == "Gemini") gemini.id else gpt.id)
        root.addView(providerGroup)

        val modelSpinner = Spinner(this)
        val models = arrayOf("자동 선택", "고성능 모델", "빠른 모델")
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models)
        root.addView(TextView(this).apply { text = "사용 모델"; textSize = 16f; setPadding(0, dp(20), 0, dp(8)) })
        root.addView(modelSpinner)

        val apiKeyInput = EditText(this).apply {
            hint = "API 키 입력"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(encryptedPrefs.getString("api_key", ""))
        }
        root.addView(TextView(this).apply { text = "API 키"; textSize = 16f; setPadding(0, dp(20), 0, dp(8)) })
        root.addView(apiKeyInput, LinearLayout.LayoutParams(-1, dp(56)))

        val status = TextView(this).apply {
            text = if (apiKeyInput.text.isNullOrBlank()) "연결 상태: 연결 필요" else "연결 상태: 키 등록됨"
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(status)

        val save = Button(this).apply {
            text = "저장"
            setOnClickListener {
                val provider = if (providerGroup.checkedRadioButtonId == gemini.id) "Gemini" else "GPT"
                encryptedPrefs.edit()
                    .putString("provider", provider)
                    .putString("api_key", apiKeyInput.text.toString().trim())
                    .putString("model", modelSpinner.selectedItem.toString())
                    .apply()
                toast("AI 설정을 안전하게 저장했습니다.")
                showHome()
            }
        }
        root.addView(save, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })

        val delete = Button(this).apply {
            text = "API 키 삭제"
            setOnClickListener {
                encryptedPrefs.edit().remove("api_key").apply()
                apiKeyInput.setText("")
                status.text = "연결 상태: 연결 필요"
                toast("API 키를 삭제했습니다.")
            }
        }
        root.addView(delete, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })

        val back = Button(this).apply {
            text = "홈으로"
            setOnClickListener { showHome() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onBackPressed() {
        showHome()
    }

    private fun addCard(title: String, body: String) {
        val box = verticalBox()
        box.addView(titleText(title))
        box.addView(TextView(this).apply {
            text = body
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(box, cardParams())
    }

    private fun verticalBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.dialog_holo_light_frame)
    }

    private fun titleText(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 19f
        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
    }

    private fun cardParams() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
