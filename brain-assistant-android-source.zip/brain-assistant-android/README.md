# 브레인 비서 Android MVP

## 현재 포함 기능
- 오늘의 브리핑 홈 화면
- 우선 업무 카드
- 빠른 입력 버튼 UI
- GPT / Gemini 제공자 선택
- API 키 암호화 저장·변경·삭제
- 모델 선택 UI
- 간단 앱 상태 검사
- 스마트폰·태블릿 기본 대응

## GitHub Actions APK 빌드
1. 이 프로젝트를 GitHub 저장소의 `main` 브랜치에 업로드합니다.
2. Actions 탭에서 `Build Android APK`를 실행합니다.
3. 빌드 완료 후 `brain-assistant-debug-apk` 아티팩트를 내려받습니다.

## 로컬 빌드
Android SDK와 Gradle 8.9가 준비된 환경에서:

```bash
gradle :app:assembleDebug
```

APK 위치:

```text
app/build/outputs/apk/debug/app-debug.apk
```
